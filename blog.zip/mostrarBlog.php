<?php
require_once "pdo.php";
    session_start();

    
/*
     $sql = 'SELECT * FROM post limit 5';
     $stmt=$pdo->prepare($sql);
     $stmt->execute();
    foreach ($stmt as $datos) {
           $usuario=$datos['idusuario'];
           $contenido=$datos['contenido'];
     }

     $sql1 = 'SELECT * FROM profesor where idProfesor='.$usuario;
     $stmt1=$pdo->prepare($sql1);
     $stmt1->execute();
    foreach ($stmt1 as $us) {
           $nombreusuario=$us['nombresProf'];
           $apellidousuario=$us['apellidosProf'];
     }*/
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <?php
    require "head.php"; //la funcion requiere en cada script toma la funcionalidad de dicho script y lo replica en este documento. Sirve para codigo limpio
  ?>

</head>
<style>
  
textarea{
   height: 50%;
   width: 100%;
   padding:10px;
   border-left: solid blue;
   background-color: lightblue;

}



</style>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    require "navbar.php";
  ?>
  <div class="content-wrapper" style="background-image: url(fondo.jpg">
    <?php //En esta parte el $_SESSION[] succes controla que un usuario se haya logueado correctamente
      if ( isset($_SESSION["success"]) ) {
          echo('<div class="alert alert-success alert-dismissable">');
          echo('<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>');
          echo('<strong>Ingreso Correcto!</strong> Ahora puede usar el sistema.');
          echo('</div>');
          unset($_SESSION["success"]);
      }

      //esta parte del codigo es el anuncia cuando un usuario se registro correctamente
      //<button>Probando <i class="fas fa-play"></i></button>
      if ( isset($_SESSION["reg"]) ) {
        echo('<div class="alert alert-success alert-dismissable">');
        echo('<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>');
        echo($_SESSION["reg"]);
        echo('</div>');
        unset($_SESSION["reg"]);
      }
    ?>
    <div id=general style="width: 100%;overflow: hidden;">
      <div style="width: 100%; height: 70px;" align="center" >  
       <img src="images/logoEPN.png" style="float:center; width:30px;height:30px;">
        <h1> Blog EPN</h1>
      
      </div>
      <div style="width: 22%;float: left; height: 429px;background-color:steelblue;">
        <h1>Información</h1>
        <h5>En construcción</h5>
        
      </div>
<div style="margin-left: 32%;height: 429px;background-color: lightblue;overflow: scroll;">
      <?php

        $idbloge=$_SESSION['idblog'];
        $sql = 'SELECT * FROM post WHERE idpost='.$idbloge;
         $stmt=$pdo->prepare($sql);
         $stmt->execute();
        foreach ($stmt as $datos) {
          ?>
          <div style="background-image: url(fondo.jpg)">
          <p>_</p>
        </div>
          <div>
          
        <h3  style="padding: 2%">
          <?php
              
          if($datos['rol']="prof"){
            $sql1 = 'SELECT * FROM profesor where idProfesor='.$datos['idusuario'];
          }
         $stmt1=$pdo->prepare($sql1);
          $stmt1->execute();
          foreach ($stmt1 as $us) {
               $nombreusuario=$us['nombresProf'];
               $apellidousuario=$us['apellidosProf'];
       }
     
     if($datos['rol']="est"){
      $sql1 = 'SELECT * FROM estudiante where idEstudiante='.$datos['idusuario'];
      }
         $stmt1=$pdo->prepare($sql1);
          $stmt1->execute();
          foreach ($stmt1 as $us) {
               $nombreusuario=$us['nombresEst'];
               $apellidousuario=$us['apellidosEst'];
       }
     echo $nombreusuario.' '.$apellidousuario
          ?></h3>
   <textarea disabled  style="padding: 2%">
          <?php
            echo $datos['contenido']
      ?></textarea>

        <?php
        echo '<img src="data:image/jpeg;base64,'.base64_encode( $datos['imagen'] ).'"/>';

?>

     
</div>
    <?php
  }
  ?>

    </div>

    
    </div>
  </div>
    <?php
      require "footer.php";
    ?>

  
</body>

</html>